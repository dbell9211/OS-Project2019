
public class CPU {
	// Global Variables 
	public int reg1, reg2, sReg1, sReg2, dReg, bReg, addr, jc;
	public String cpuID;
	public String cache[];
	public int pc;
	public Register currentRegisters;
	public PCB currentPCB; 
	public String InputBuffer, OutputBuffer, TempBuffer; // NOT USED, used for first 2 OpCodes
	
	// Constructor
	public CPU(PCB pcb) {
		// setCache(cache);
		pc = pcb.getPC(); // Get current PC from PCB
		// Maybe other initialization here? 
	}
	
	// Called to fetch instruction
	private String fetch(int pc) {
		String instruct = cache[pc];
		jc++; // Increment amount of jobs
		return instruct;
	}
	
	// Called to decode fetch()
	public int decode(String instruct) {
		String binInstr = hexToBinary(instruct.substring(2));
		String tmpInstr = binInstr;
		int instType = Integer.parseInt(tmpInstr.substring(0,2));
		int opCode = binaryStringToInteger(tmpInstr.substring(2,8));
		
		switch(instType) {
		case 00:
			// Arithmetic or logical operation
			sReg1 = binaryStringToInteger(tmpInstr.substring(8,12));
			sReg2 = binaryStringToInteger(tmpInstr.substring(12,16));
			dReg = binaryStringToInteger(tmpInstr.substring(16,20));
			break;
		case 01: 
			// Conditional Jump
			bReg = binaryStringToInteger(tmpInstr.substring(8,12));
			dReg = binaryStringToInteger(tmpInstr.substring(12,16));
			addr = binaryStringToInteger(tmpInstr.substring(16));
			break;
		case 10: 
			// Unconditional Jump
			addr = binaryStringToInteger(tmpInstr.substring(8));
			break;
		case 11:
			// IO Operation 
			reg1 = binaryStringToInteger(tmpInstr.substring(8,12));
			reg2 = binaryStringToInteger(tmpInstr.substring(12,16));
			addr = binaryStringToInteger(tmpInstr.substring(16));
			break;
		default:
			System.out.println("EXCEPTION: Invalid Instruction Type");
		}
		return opCode;
	}
	
	// Called by run() to execute given opCode
	public void execute(int opCode) {
		
		switch (opCode) {
		// Read Content of I/P buffer into a accumlator
		case 0:
			System.out.println("Executing Read OpCode");
		// Writes the content of accumulator into O/P buffer
		case 1: 
			System.out.println("**Executing Write OpCode");
			// TODO
		// Stores content of a reg. into an address
		case 2: 
			addr = currentRegisters.getReg(dReg);
			break;
		// Loads the content of an address into a reg
		case 3:
		// Transfers the content of one register into another
			currentRegisters.setReg(currentRegisters.getReg((int)addr), dReg);
			break;
		case 4:
			System.out.println("Executing Move OpCode");
			currentRegisters.setReg(currentRegisters.getReg(reg1), reg2);
			break;
		// Adds content of two S-regs into D-regs
		case 5:
			System.out.println("Executing ADD OpCode");
			currentRegisters.setReg(currentRegisters.getReg(sReg1) + currentRegisters.getReg(sReg2), dReg); // Add values of sreg1 + sreg2 -> dReg
			break;
		// SUB
		case 6:
			System.out.println("Executing SUB OpCode");
			currentRegisters.setReg(currentRegisters.getReg(sReg1) - currentRegisters.getReg(sReg2), dReg); // Sub values of sreg1 - sreg2 -> dReg
			break;
		// MUL
		case 7:
			System.out.println("Executing MUL OpCode");
			currentRegisters.setReg(currentRegisters.getReg(sReg1) * currentRegisters.getReg(sReg2), dReg);
			break;
		// DIV
		case 8:
			System.out.println("Executing DIV OpCode");
			if (currentRegisters.getReg(sReg2) == 0) {
				System.out.println("Error division by 0");
			} else {
			currentRegisters.setReg(currentRegisters.getReg(sReg1) / currentRegisters.getReg(sReg2), dReg);
			}
			break;
		// AND
		case 9:
			System.out.println("Executing AND OpCode");
			currentRegisters.setReg(currentRegisters.getReg(reg1) & currentRegisters.getReg(reg2), dReg);
			break;
		// 0A - OR
		case 10:
			System.out.println("Executing OR OpCode");
			currentRegisters.setReg(currentRegisters.getReg(reg1) | currentRegisters.getReg(reg2), dReg);
			break;
		// 0B - MOVI
		case 11:
			System.out.println("Executing MOVI OpCode");
			currentRegisters.setReg((int)addr, dReg); // Cast string addr as int and move to dReg
			break;
		// OC - ADDI
		case 12:
			System.out.println("Executing ADDI OpCode");
			currentRegisters.setReg((int)addr + currentRegisters.getReg(dReg), dReg); // Cast string addr as int and add with dReg, replacing dReg with value
			break;
		// 0D - MULI
		case 13:
			System.out.println("Execuing MULI OpCode");
			currentRegisters.setReg((int)addr * currentRegisters.getReg(dReg), dReg);
			break;
		// 0E - DIVI
		case 14:
			System.out.println("Execuing DIVI OpCode");
			if (currentRegisters.getReg(dReg) == 0) {
				System.out.println("Error division by 0");
			} else {
				currentRegisters.setReg((int)addr / currentRegisters.getReg(dReg), dReg);
			}
			break;
		// 0F - LDI
		case 15:
			System.out.println("Executing LDI OpCode");
			currentRegisters.setReg((int)addr, dReg); // Cast value of addr(string) to int and replace dReg
			break;
		// 10 - SLT
		case 16:
			if (currentRegisters.getReg(sReg1) < currentRegisters.getReg(sReg2))
				currentRegisters.setReg(1, dReg);
			else {
				currentRegisters.setReg(0, dReg);
			}
			break;
		// 11 - SLTI
		case 17:
			System.out.println("Executing SLTI OpCode");
			if (currentRegisters.getReg(sReg1) < (int)addr) 
				currentRegisters.setReg(1, dReg);
			else 
				currentRegisters.setReg(0, dReg);
			break;
		// 12 - HLT 
		case 18:
			System.out.println("Executing HLT OpCode");
			pc = 0; // Logical End to Program
			// METRICS
			break;
		// 13 - NOP
		case 19:
			System.out.println("Executing NOP OpCode");
			break;
		// 14 - JMP (WRONG)
		case 20:
			System.out.println("Executing JMP OpCode");
			pc = (int)addr / 4; // Jump to another location
			break;
		// 15 - BEQ
		case 21:
			System.out.println("Executing BEQ OpCode");
			if (currentRegisters.getReg(dReg) == currentRegisters.getReg(bReg)) 
				pc = (int)addr / 4; // Jump to another location
			break;
		// 16 - BNE
		case 22:
			System.out.println("Executing BNE OpCode");
			if (currentRegisters.getReg(dReg) != currentRegisters.getReg(bReg));
				pc = (int)addr / 4; // Jump to another location
			break;
		// 17 - BEZ
		case 23:
			System.out.println("Executing BEZ OpCode");
			if (currentRegisters.getReg(bReg) == 0) 
				pc = (int)addr / 4;
			break;
		// 18 - BNZ
		case 24:
			System.out.println("Executing BNZ OpCode");
			if (currentRegisters.getReg(bReg) != 0)
				pc = (int)addr / 4;
			break;
		// 19 - BGZ
		case 25:
			System.out.println("Executing BGZ OpCode");
			if (currentRegisters.getReg(bReg) > 0) {
				pc = (int)addr / 4;
			break;
			}
		// 1A - BLZ
		case 26:
			System.out.println("Executing BLZ OpCode");
			if (currentRegisters.getReg(bReg) < 0)
				pc = (int)addr / 4;
			break;
		// Default Case
		default: 
			System.out.println("Invalid Operation");
		}
	}
	
	// Runs all commands while pc < jc
	public void run() {
		// Job Available
		while (pc < jc) {
			try {
				execute(decode(fetch(pc)));
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
	
	// Function to change the string of hex to string of binary
	public String hexToBinary(String hex) {
		int temp = Integer.parseInt(hex, 16); // Convert hex string to decimal value
		String binStr = Integer.toBinaryString(temp); // Convert int temp to a binary string
		return binStr;
	}
	
	// Function to change the string of binary to integer
	public int binaryStringToInteger(String nbinStr) {
		int nInt = Integer.parseInt(nbinStr, 2); // Change binary string to int value
		return nInt;
	}
	
	// Getter for cache
	public String[] getCache() {
		return cache;
	}
	
	// Setter for cache
	public void setCache(String [] cache_) {
		cache = cache_;
	}
	
}